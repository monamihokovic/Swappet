import React, {useState, useEffect} from "react";
import { useNavigate } from "react-router-dom";
import "../css/AdminReported.css";
import axios from "axios";
import Header from "./Header";

const defaultProfilePic = "/defaultpfp.jpg";

const AdminReported=()=>{ 
    const [user, setUser] = useState(null); //inicijalizacija korisnika
    const [reportedAccounts] = useState([]); //inicijalizacija prijavljenih računa

    //dohvati informacije o korisniku
    useEffect(() => {
        axios
            .get(`${process.env.REACT_APP_BACKEND_URL}/user-info`, {
                withCredentials: true,
            })
            .then((response) => {
                setUser(response.data);
            })
            .catch((error) => {
                console.error("Error occurred: ", error);
            });
    }, []);

    //rukovanje 'banom'
    const handleBan = (email, action) =>{
        const response = axios.post(
            `${process.env.REACT_APP_BACKEND_URL}/admin/ban`,
            {email: email, ban: action})
            .then((response)=>{
                console.log("Akcija je uspješna: ", response.data);
            }).catch((error)=>{
                console.log("Došlo je do pogreške:", error);
            });
    };

    return(
        <div className="admin-page">
            <Header></Header>
            <div className="container-korisnika">
                <div id="reported">Svi prijavljeni korisnici</div>
                <div className="useri">
                {reportedAccounts.length === 0 ? (
                        <div className="no-events-message">
                            Nema prijavljenih korisnika.
                        </div>
                    ) : (
                        reportedAccounts.map((user) => (
                            <div className="korisnik">
                                <div id="email">Korisnik: {user}</div>
                                <button value={0} onClick={handleBan(user, 0)} className="ban-button">Oslobodi</button>
                                <button value={1} onClick={handleBan(user, 1)} className="ban-button">Zabrani</button>
                            </div>
                        ))
                    )}
                </div>
            </div>
        </div>
    );
};
export default AdminReported;